import "./style.css";
console.log("Hello My Friends!");


const students = [
  {
    name: "Misha",
    marks: [5, 7, 9, 6, 5]
  },
  {
    name: "Maksim",
    marks: [10, 9, 8, 7, 6]
  },
  {
    name: "Sasha",
    marks: [9, 6, 9, 8, 8]
  },
  {
    name: "Elena",
    marks: [10, 7, 6, 9, 5]
  },
  {
    name: "Brandon",
    marks: [9, 8, 8, 9, 10]
  }
];

let namestudMarks = (array) => {
  for (let person of array) {
    console.log(person.name + ': ' + person.average);
  }
}

let AverageMark = (students) => {
  const marks = [];
  for (let i in students) {
    let sum = 0;
    for (let j in students[i].marks) {
      sum += students[i].marks[j];
    }
    const student = {};

    student.name = students[i].name;
    student.average = sum / students[i].marks.length;
    marks.push(student);
  }
  return marks;
}

namestudMarks(AverageMark(students));

console.log(" ");


document.getElementById("but1").addEventListener("click", function () {
  alert("Здравствуйте, студенты!");
});