//import $ from 'jquery';
import avg from './some.js';

//$('.title').html('Some text!')

console.log(avg(1, 4, 8));

import './css/style.css';